package com.java.w3schools.blog.access.modifiers;

public interface MyPublicInterface {

	public static final double PI = 3.14;

	public abstract Student	getTopStudent();

}


class Student {
	
}