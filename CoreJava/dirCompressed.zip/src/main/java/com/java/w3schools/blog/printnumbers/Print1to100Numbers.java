package com.java.w3schools.blog.printnumbers;

/**
 * 
 * @author Venkatesh
 *
 */
public class Print1to100Numbers {

	public static void main(String[] args) {

		// for loop
		for (int i = 1; i <= 100; i++) {
			System.out.println(i);
		}

		// while loop
		int j = 1;
		while (j <= 100) {
			System.out.println(j);
			j++;
		}
	}

}
