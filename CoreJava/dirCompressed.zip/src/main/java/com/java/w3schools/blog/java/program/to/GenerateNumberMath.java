package com.java.w3schools.blog.java.program.to;

/**
 * 
 * java program to generate a random number using Math.random().
 * 
 * @author venkateshn
 *
 */
public class GenerateNumberMath {

	public static void main(String[] args) {

		// genrating a first random double number using Math.random()
		double mathRandomNumber1 = Math.random();
		System.out.println("First number using Math.random() : " + mathRandomNumber1);

		// generating a Second random double number using Math.random()
		double mathRandomNumber2 = Math.random();
		System.out.println("Second number using Math.random() : " + mathRandomNumber1);

		// generating a Third random double number using Math.random()
		double mathRandomNumber3 = Math.random();
		System.out.println("Third number using Math.random() : " + mathRandomNumber3);

	}

}
