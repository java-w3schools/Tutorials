package com.java.w3schools.blog.access.modifiers;

// Java public access modifiers.

public class JavaGlobalClass {

	public boolean isGloble = true;

	public JavaGlobalClass() {
		// Creating instance.
	}

	public boolean getGlobalStatus() {

		return isGloble;
	}
}	