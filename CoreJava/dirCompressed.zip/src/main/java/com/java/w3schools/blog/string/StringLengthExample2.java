package com.java.w3schools.blog.string;

public class StringLengthExample2 {
	public static void main(String[] args) {

		String input1 = "java-w3schools";
		int length1 = input1.length();
		System.out.println("Input String length1: " + length1);

		String input2 = "string length method";
		int length2 = input2.length();
		System.out.println("Input String length2: " + length2);

		String input3 = "";
		int length3 = input3.length();
		System.out.println("Input String length3: " + length3);
	}
}
