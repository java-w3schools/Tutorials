package com.java.w3schools.blog.java11.string;

public class RepeatExample {

	public static void main(String[] args) {
		String outputString = "Hola " + "la ".repeat(4);
		System.out.println(outputString);
	}

}
