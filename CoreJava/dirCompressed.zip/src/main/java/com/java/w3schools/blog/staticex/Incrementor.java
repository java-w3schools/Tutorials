package com.java.w3schools.blog.staticex;

public class Incrementor {

	static int value = 0;

	public static int incrementByOne() {
		return value+1;
	}

}
