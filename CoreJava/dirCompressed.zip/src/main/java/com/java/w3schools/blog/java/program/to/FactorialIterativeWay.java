package com.java.w3schools.blog.java.program.to;

import java.util.Scanner;

/**
 * 
 * Java Program to Find Factorial for a number using Iterative approach.
 * 
 * @author javaprogramto.com venkateshn
 *
 */
public class FactorialIterativeWay {

	public static void main(String[] args) {

		System.out.println("Reading the input from user.");
		Scanner s = new Scanner(System.in);

	}

}
