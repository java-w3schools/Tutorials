package com.java.w3schools.blog.staticex;

public class StaticInstanceVariableExample {

	public static void main(String[] args) {

		System.out.println(PerformAction.performCountInc());
	}

}
