package com.java.w3schools.blog.string;

public class StringcodePointAtExample3 {
	public static void main(String[] args) {

		String input = "JAVA-W3SCHOOLS";
		input.codePointAt(input.length()+1);

	}
}
